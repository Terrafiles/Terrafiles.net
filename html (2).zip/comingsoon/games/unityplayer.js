if (document.location.hostname === somethingcool) {
                while(true) {
                    alert("CACTI4.NET HAS BEEN HACKED")
                }
            }