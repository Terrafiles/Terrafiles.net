<?php
date_default_timezone_set("America/Los_Angeles");

session_start();

if (isset($_GET['logout'])) {

    //Simple exit message
    $logout_message = "<div class='msgln'><span class='left-info'>User <b class='user-name-left'>" . $_SESSION['name'] . "</b> has left the chat session.</span><br></div>";
    file_put_contents("log.html", $logout_message, FILE_APPEND | LOCK_EX);

    session_destroy();
    header("Location: index.php"); //Redirect the user
}

if (isset($_POST['enter'])) {
    if ($_POST['name'] != "") {
        $_SESSION['name'] = stripslashes(htmlspecialchars($_POST['name']));
    } else {
        echo '<span class="error">Please type in a name</span>';
    }
}

function loginForm()
{
    echo
    '<div class="sidenav">
        <p class="logout"><a id="exit" href="#">Exit Chat</a></p>
  <a href="https://terrafiles.net/servers/mainchat">Main Chat</a>
  <a href="https://terrafiles.net/servers/server1">General</a>
  <a href="https://terrafiles.net/servers/server2/">Memes</a>
  <a href="https://terrafiles.net/servers/server3">Random</a>
  <a href="https://terrafiles.net/servers/server4">Spam</a>
  <a href="https://terrafiles.net/servers/server5">Bug Report</a> 
</div>
    <div id="loginform">
    <form action="index.php" method="post">
      <p class="jkjaksasjakskaska">Enter Your Name</p>
      <label for="name">Name &mdash;</label>
      <input type="text" name="name" id="name" maxlength="20" />
      <input type="submit" name="enter" id="enter" value="Enter" />
    </form>
  </div>';
}

?>

<!DOCTYPE html>
<html lang=”en-US”>

<head>
    <meta charset="utf-8" />

    <title>Chat</title>
    <link rel="apple-touch-icon" href="favicon.ico">
    <link rel="stylesheet" href="style.css">

    <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100&family=Quicksand:wght@300&family=Readex+Pro:wght@200&family=Roboto:wght@500&display=swap');
    </style>
    <meta name=viewport content="width=device-width, initial-scale=1">
    <meta name="description" content="Terrafiles Chat">
    <style>
body {
  font-family: 'Readex Pro', sans-serif;
}

.sidenav {
  height: 100%;
  width: 250px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  padding-top: 20px;
}
.sidenav a {
  padding: 12px 12px 12px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.main {
  margin-left: 200px; /* Same as the width of the sidenav */
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
#exit {
    background: #3498db;
    background-image: -webkit-linear-gradient(top, #3498db, #2980b9);
    background-image: -moz-linear-gradient(top, #3498db, #2980b9);
    background-image: -ms-linear-gradient(top, #3498db, #2980b9);
    background-image: -o-linear-gradient(top, #3498db, #2980b9);
    background-image: linear-gradient(to bottom, #3498db, #2980b9);
    -webkit-border-radius: 28;
    -moz-border-radius: 28;
    border-radius: 28px;
    text-align: center;
    font-family: Arial;
    color: #ffffff;
    font-size: 20px;
    padding: 10px 20px 10px 10px;
    text-decoration: none;
}
 .br {
     margin-bottom: 1px;
        }
#exit:hover {
    background: #3cb0fd;
    background-image: -webkit-linear-gradient(top, #3cb0fd, #3498db);
    background-image: -moz-linear-gradient(top, #3cb0fd, #3498db);
    background-image: -ms-linear-gradient(top, #3cb0fd, #3498db);
    background-image: -o-linear-gradient(top, #3cb0fd, #3498db);
    background-image: linear-gradient(to bottom, #3cb0fd, #3498db);
    text-decoration: none
}

#chatbox {
    text-align: center;
    margin: none;
    border: none;
    overflow: auto;
    position: relative;
    left: 10px;
    padding: none;
}

.msgln {
    font-size: 19px;
    font-family: 'Quicksand', sans-serif;
    color: white;
}

.clear {
    color: purple;
}

.user-name-clear {
    color: blue;
    font-weight: 1000;
}

.user-name {
    padding: 3px;
    background-clip: content-box;
    box-shadow: inset 0 0 0 15px #0096C7;
    border-radius: 25px;
    font-weight: 2000;
}

#name {
    position: relative;
    left: 460.9999999999999999999999999999999999999999999999999999999999999999999999px;
    right: 100px;
    top: 100px;
    /* fonts */
    font-family: 'Quicksand', sans-serif;
    font-size: 20px;
    content: 30px;
    color: blue;
}

#enter {
    font-family: 'Quicksand', sans-serif;
    font-size: 19px;
    text-align: center;
    color: blue;
    position: relative;
    left: 450.9999999999999999999999999999999999999999999999999999999999999999999999px;
    right: 100px;
    top: 100px;
}

.jkjaksasjakskaska {
    font-family: 'Poppins', sans-serif;
    color: white;
    position: relative;
    font-weight: 1000;
    left: 534.9999999999999999999999999999999999999999999999999999999999999999999999px;
    right: 100px;
    top: 75px;
    font-size: 30.9999999999999999999999999999999px;
    border: none;
    padding: none;
    margin: none;
}
.logout {
    text-align: center;
}
body {
    background-color: black;
    overflow-x: hidden;
  overflow-y: scroll;
}

.user-name-left {
    color: purple;
    font-weight: bold;
}

.left-info {
    color: red;
}

.sendbutton {
    -moz-box-shadow: inset 0px -3px 7px 0px #29bbff;
    -webkit-box-shadow: inset 0px -3px 7px 0px #29bbff;
    box-shadow: inset 0px -3px 7px 0px #29bbff;
    background: -webkit-gradient(linear, left top, left bottom, color-stop(0.05, #2dabf9), color-stop(1, #0688fa));
    background: -moz-linear-gradient(top, #2dabf9 5%, #0688fa 100%);
    background: -webkit-linear-gradient(top, #2dabf9 5%, #0688fa 100%);
    background: -o-linear-gradient(top, #2dabf9 5%, #0688fa 100%);
    background: -ms-linear-gradient(top, #2dabf9 5%, #0688fa 100%);
    background: linear-gradient(to bottom, #2dabf9 5%, #0688fa 100%);
    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#2dabf9', endColorstr='#0688fa', GradientType=0);
    background-color: #2dabf9;
    -webkit-border-radius: 42px;
    -moz-border-radius: 42px;
    border-radius: 42px;
    display: inline-block;
    cursor: pointer;
    color: #ffffff;
    font-family: Arial;
    font-size: 15px;
    
    padding: 2px 10px;
    text-decoration: none;
    text-shadow: 0px 1px 0px #263666;
}

.sendbutton:hover {
    background: -webkit-gradient(linear, left top, left bottom, color-stop(0.05, #0688fa), color-stop(1, #2dabf9));
    background: -moz-linear-gradient(top, #0688fa 5%, #2dabf9 100%);
    background: -webkit-linear-gradient(top, #0688fa 5%, #2dabf9 100%);
    background: -o-linear-gradient(top, #0688fa 5%, #2dabf9 100%);
    background: -ms-linear-gradient(top, #0688fa 5%, #2dabf9 100%);
    background: linear-gradient(to bottom, #0688fa 5%, #2dabf9 100%);
    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#0688fa', endColorstr='#2dabf9', GradientType=0);
    background-color: #0688fa;
}

.sendbutton:active {
    position: relative;
    top: 1px;
}

#usermsg,
.sendbutton,
#chatbox {
    position: relative;
    left: 150px;
    font-family: 'Readex Pro', sans-serif;
}
#usermsg, .sendbutton {
    font-size: 18px;
}
.welcome {
    color: blue;
    font-family: 'Poppins', sans-serif;
    font-weight: 900;
    position: relative;
    font-size: 55px;
    left: 150px;
    top: 50px;
}
.container {
  display: flex;
  flex-wrap: wrap;
  flex-direction: column;
  justify-content: start;
  align-items: auto;
  align-content: center
}
.container:after {
  display: block;
  content: " placeholder ";
  margin: 18px;
  flex: 999 999 auto;
}
.item {
  flex: 0 0 auto;
  margin: 18px;
  color: white;
}
</style>
    <noscript>
  <meta http-equiv="refresh" content="0; URL=/Hell.html">
</noscript>

    <meta name=”description" content="This is the offical Terrafiles Chat.">
</head>

<body>
    <?php
    if (!isset($_SESSION['name'])) {
        loginForm();
    } else {
    ?>
    <?php
        $file = "log.html"

        ?>
        <div class="sidenav">
        <p class="logout"><a id="exit" href="#">Exit Chat</a></p>
  <a href="https://terrafiles.net/servers/server1">General</a>
  <a href="https://terrafiles.net/servers/server2">Memes</a>
  <a href="https://terrafiles.net/servers/server3">Random</a>
  <a href="https://terrafiles.net/servers/server4">Spam</a>
  <a href="https://terrafiles.net/servers/server5">Bug Report</a> 
</div>

    <div id="wrapper">
        <div id="menu">
            <center>
                <p class="welcome">Welcome, <b><?php echo $_SESSION['name']; ?></b></p>
            </center>
        </div>
        <br />
        <div id="chatbox">
            <?php
                if (file_exists("log.html") && filesize("log.html") > 0) {
                    $contents = file_get_contents("log.html");
                    echo $contents;
                }
                ?>
        </div>

        <form name="message" action="">
            <center>
                <input name="usermsg" type="text" id="usermsg" maxlength="60" required />
                <input class="sendbutton" name="submitmsg" type="submit" id="submitmsg" value="Send" />
            </center>
        </form>
    </div>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script type="text/javascript">
    // jQuery Document
    $(document).ready(function() {
        $("#submitmsg").click(function() {
            var clientmsg = $("#usermsg").val();
            $.post("post.php", {
                text: clientmsg
            });
            $("#usermsg").val("");
            return false;
        });

        function loadLog() {
            var oldscrollHeight = $("#chatbox")[0].scrollHeight - 20; //Scroll height before the request

            $.ajax({
                url: "log.html",
                cache: false,
                success: function(html) {
                    $("#chatbox").html(html); //Insert chat log into the #chatbox div

                    //Auto-scroll			
                    var newscrollHeight = $("#chatbox")[0].scrollHeight -
                        20; //Scroll height after the request
                    if (newscrollHeight > oldscrollHeight) {
                        $("#chatbox").animate({
                            scrollTop: newscrollHeight
                        }, 'normal'); //Autoscroll to bottom of div
                    }
                }
            });
        }

        setInterval(loadLog, 82.8);

        $("#exit").click(function() {
            var exit = confirm("Are you really sure that you want to leave?");
            if (exit == true) {
                window.location = "index.php?logout=true";
            }
        });
    });
    </script>
</body>

</html>
<?php
    }
?>