var $ = document.getElementById;

$("body").style.backgroundColor = "black";